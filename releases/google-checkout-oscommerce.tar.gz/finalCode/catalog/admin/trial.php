<?php

/* This is just a test php file to try out test code to become more familiar with php syntax*/

echo 'hello world';
echo HTML_PARAMS;
echo TITLE;

?>