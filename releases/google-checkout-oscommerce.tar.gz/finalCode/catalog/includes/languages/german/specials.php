<?php
/*
  $Id: specials.php,v 1.6 2002/04/17 15:57:07 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Angebote');
define('HEADING_TITLE', 'Unsere Sonderangebote:');
?>