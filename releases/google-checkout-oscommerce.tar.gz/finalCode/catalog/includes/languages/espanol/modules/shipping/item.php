<?php
/*
  $Id: item.php,v 1.6 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ITEM_TEXT_TITLE', 'Por art�culo');
define('MODULE_SHIPPING_ITEM_TEXT_DESCRIPTION', 'Por art�culo');
define('MODULE_SHIPPING_ITEM_TEXT_WAY', 'La Mejor Opcion');
?>
