<?php
/*
  $Id: secpay.php,v 1.8 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_SECPAY_TEXT_TITLE', 'SECPay');
  define('MODULE_PAYMENT_SECPAY_TEXT_DESCRIPTION', 'Tarjeta de Cr&eacute;dito para Pruebas:<br><br>Numero: 4444333322221111<br>Caducidad Cualquiera');
  define('MODULE_PAYMENT_SECPAY_TEXT_ERROR', 'Error de Tarjeta de Cr&eacute;dito!');
  define('MODULE_PAYMENT_SECPAY_TEXT_ERROR_MESSAGE', 'Ha ocurrido un error procesando su tarjeta de cr&eacute;dito. Por favor, intentelo de nuevo.');
?>
