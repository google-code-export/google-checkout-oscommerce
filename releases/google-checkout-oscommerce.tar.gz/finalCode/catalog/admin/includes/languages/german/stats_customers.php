<?php
/*
  $Id: stats_customers.php,v 1.9 2002/03/30 15:03:59 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Kunden mit den h&ouml;chsten Ums&auml;tzen');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_CUSTOMERS', 'Kunde');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Gesamtsumme');
?>